<?php                                                                                     
session_start();
if (!isset($_SESSION['user_level']) or ($_SESSION['user_level'] != 1))
{ header("Location: login.php");
exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Template for an interactive web page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" 
  href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
   <script src="script/script.js"></script> 
</head>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {                               
    require('process-addbook.php');
   } 
?>
<div class="col-sm-8">
<h2 class="h2 text-center">Add Book</h2>
<form action="addbook.php" method="post" onsubmit="return checked();"
name="regform" id="regform">
  <div class="form-group row">
    <label for="book" class="col-sm-4 col-form-label">First Name:</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="book" name="book" 
	  placeholder="Book Name" required
	  value="<?php if (isset($_POST['book'])) $book=$_POST['book']; ?>" >
    </div>
  </div>
  <div class="form-group row">
    <label for="link" class="col-sm-4 col-form-label">Link</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="link" name="link" 
	  placeholder="Link" required
	  value="<?php if (isset($_POST['link'])) $link=$_POST['link']; ?>">
    </div>
  </div>

<div class="form-group row">
    <div class="col-sm-12">
	<input id="submit" class="btn btn-primary" type="submit" name="submit" value="Add Book">
    </div>
	</div>
	</form>
</div>


</div>
</body>
</html>
