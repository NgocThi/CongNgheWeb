<?php
	$errors = array(); // Initialize an error array. 
	// Check for a first name:                        
        $first_name = filter_var( $_POST['first_name'], FILTER_SANITIZE_STRING);	
	if (empty($first_name)) {
		$errors[] = 'You forgot to enter your first name.';
	}
	// Check for a last name:
	    $last_name = filter_var( $_POST['last_name'], FILTER_SANITIZE_STRING);	
	if (empty($last_name)) {
		$errors[] = 'You forgot to enter your last name.';
	}
	// Check for an email address:
	    $email = filter_var( $_POST['email'], FILTER_SANITIZE_EMAIL);	
	if  ((empty($email)) || (!filter_var($email, FILTER_VALIDATE_EMAIL))) {
		$errors[] = 'You forgot to enter your email address';
		$errors[] = ' or the e-mail format is incorrect.';
	}
	// Check for a password and match against the confirmed password:
			$password1 = filter_var( $_POST['password1'], FILTER_SANITIZE_STRING);
			$password2 = filter_var( $_POST['password2'], FILTER_SANITIZE_STRING);
	if (!empty($password1)) {
		if ($password1 !== $password2) { 
			$errors[] = 'Your two password did not match.';
		} 
	} else {
		$errors[] = 'You forgot to enter your password(s).';
	}
	if (empty($errors)) { 
	    $hashed_passcode = password_hash($password1, PASSWORD_DEFAULT); 
		require ('mysqli_connect.php');                                               
		$query = "INSERT INTO users (first_name, last_name, email, password, registration_date) VALUES('$first_name', '$last_name', '$email', '$hashed_passcode', NOW()) ";		                
        $result = mysqli_query($dbcon,$query);
       
        if ($result == 1) {				
            header ("location: login.php"); 
        }
        else{
            echo('Fail');
        }
        mysqli_close($dbcon);
    }
?>