<?php                                                                                     
session_start();
if (!isset($_SESSION['user_level']) or ($_SESSION['user_level'] != 1))
{ header("Location: login.php");
exit();
}
?>
<?php
        DEFINE ('DB_USER', 'root');
        DEFINE ('DB_PASSWORD', '');
        DEFINE ('DB_HOST', 'localhost');
        DEFINE ('DB_NAME', 'realdb');
        
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        
        mysqli_set_charset($conn, 'utf8'); 
        $book = filter_var( $_POST['book'], FILTER_SANITIZE_STRING);
        $link = filter_var( $_POST['link'], FILTER_SANITIZE_STRING);
        if(!$conn){
            die('Stop');
        }
        else{                                               
		$query = "INSERT INTO sach (nameBook, link, add_day) VALUES('$book', '$link', NOW()) ";		                
        $result = mysqli_query($conn,$query);
       
        if ($result == 1) {			
            header ("location: admin-library.php"); 
        }
        else{
            echo('Fail');
        }
        mysqli_close($conn);
    }
?>