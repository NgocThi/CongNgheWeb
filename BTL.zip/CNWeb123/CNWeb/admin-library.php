<?php                                                                                     
session_start();
if (!isset($_SESSION['user_level']) or ($_SESSION['user_level'] != 1))
{ header("Location: login.php");
exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styleAdmin-library.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-light bg-light ">
        <div class="container-fluid">
            <img class="navbar-branch" src="http://cse.tlu.edu.vn/cse/assets/images/logo.jpg" alt="">
            <button class="navbar-toggler" type="button" data-toggle='collapse' data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div style="font-size: 20px; font-family: Arial, Helvetica, sans-serif;" class="collapse navbar-collapse"
                id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a style="color: #3333FF" class="nav-link" href="">Login</a>
                    </li>
                    <li class="nav-item">
                        <a style="color: #3333FF" class="nav-link" href="">Register</a>
                    </li>
                </ul>
            </div>
            <form class="form-inline" action="">
                <input class="form-control mr-sm-2" type="text" placeholder="Search">
                <button style="background-color:#3333FF;" class="btn btn-success" type="submit">Search</button>
            </form>
        </div>
    </nav>
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">

        <ul style="width: 100%; text-align:center; background-color: #3366FF;  ">
            <div class="dropdown">
                <div class="dropbtn">TRANG CHỦ</div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">GIỚI THIỆU</div>
                <div class="dropdown-content">
                    <a href="#">Lời chào mừng</a>
                    <a href="#">Tổ chức</a>
                    <a href="#">Hợp tác liên kết</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">NGHIÊN CỨU KHOA HỌC</div>
                <div class="dropdown-content">
                    <a href="#">Các đề tài-dự án</a>
                    <a href="#">Hợp tác phát triển</a>

                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">ĐÀO TẠO</div>
                <div class="dropdown-content">
                    <a href="#">Đào tạo Đại học</a>
                    <a href="#">Đào tạo sau Đại học</a>
                    <a href="#">Chuẩn đầu ra</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">BỘ MÔN TRUNG TÂM</div>
                <div class="dropdown-content">
                    <a href="#">Công nghệ phần mềm</a>
                    <a href="#">Hệ thống thông tin</a>
                    <a href="#">Khoa học máy tính</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">TIN TỨC</div>
                <div class="dropdown-content">
                    <a href="#">Sự kiện</a>
                    <a href="#">CSE trên báo</a>

                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">THÔNG BÁO</div>
                <div class="dropdown-content">
                    <a href="#">Tuyển dụng</a>
                    <a href="#">TB đào tạo</a>
                    <a href="#">Học bổng</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">LIÊN HỆ</div>

            </div>
        </ul>

    </nav>

    <h2  style="text-align: center">  THƯ VIỆN ĐẠI HỌC THỦY LỢI</h2>
    <p  style="text-align: center">    Thư viện là kho tàng chứa tất cả của cải tinh thần của loài người --- G.V.Leibniz:</p>   
    <?php
        DEFINE ('DB_USER', 'root');
        DEFINE ('DB_PASSWORD', '');
        DEFINE ('DB_HOST', 'localhost');
        DEFINE ('DB_NAME', 'realdb');
        // Make the connection:
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        // Set the encoding...optional but recommended
        mysqli_set_charset($conn, 'utf8'); 
        
        if(!$conn){
            die('Stop');
        }
        else{
            $sql = 'SELECT * FROM sach';
            $result = mysqli_query($conn,$sql);
            echo '<table style="border:1px solid;">';
            echo '<tr><th style="border:1px solid;">ID</th><th style="border:1px solid;text-align:center;">Book</th><th style="border:1px solid;text-align:center;">Link</th></tr>';
    
            while($row = mysqli_fetch_assoc($result)){
                echo '<tr>';
                echo '<td style="border:1px solid;">'.$row['bookId'].'</td>';
                echo '<td style="border:1px solid;">'.$row['nameBook'].'</td>';
                echo '<td style="border:1px solid;">'.$row['link'].'</td>';
                echo '</tr>';
            }
            echo '</table>';
        }
    ?>

    <div class="col-sm-12">
	<a style="margin-top: 50px; float:left;" class="btn btn-primary" type="submit" href="http://localhost:88/CNWeb123/CNWeb/addbook.php">Add Book</a>
    </div>
    <div class="col-sm-12">
	<a style="margin-top: 50px; float:right;" class="btn btn-primary" type="submit" href="">Delete Book</a>
    </div>
</body>
</html>