<?php
    DEFINE ('DB_USER', 'root');
    DEFINE ('DB_PASSWORD', '');
    DEFINE ('DB_HOST', 'localhost');
    DEFINE ('DB_NAME', 'realdb');
    // Make the connection:
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    $bookId = $_POST['bookId'];
    // Set the encoding...optional but recommended
    mysqli_set_charset($conn, 'utf8'); 
    
    if(!$conn){
        die('Stop');
    }
    else{
        $sql = "DELETE FROM users WHERE bookId = '$bookId'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_query($conn,$sql)==TRUE){
            echo 'Da xoa';
        }
        else{
            echo 'Ko the xoa';
        }
    }

?>