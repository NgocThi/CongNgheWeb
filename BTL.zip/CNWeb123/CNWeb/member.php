<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-light bg-light ">
        <div class="container-fluid">
            <img class="navbar-branch" src="http://cse.tlu.edu.vn/cse/assets/images/logo.jpg" alt="">
            <button class="navbar-toggler" type="button" data-toggle='collapse' data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div style="font-size: 20px; font-family: Arial, Helvetica, sans-serif;" class="collapse navbar-collapse"
                id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                        <a style="color: #3333FF" class="nav-link" href="http://localhost:88/CNWeb123/CNWeb/login.php">Login<a>
                    </li>
                    <li class="nav-item">
                        <a style="color: #3333FF" class="nav-link" href="http://localhost:88/CNWeb123/CNWeb/register.php">Register</a>
                    </li>
                    <li class="nav-item">
                        <a style="color: #3333FF" class="nav-link" href="http://localhost:88/CNWeb123/CNWeb/library.php">Books</a>
                    </li>
                </ul>
            </div>
            <form class="form-inline" action="">
                <input class="form-control mr-sm-2" type="text" placeholder="Search">
                <button style="background-color:#3366FF;" class="btn btn-success" type="submit">Search</button>
            </form>
        </div>
    </nav>
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">

        <ul style="width: 100%; text-align:center; background-color: #3366FF;  ">
            <div class="dropdown">
                <div color = "" class="dropbtn">
                <a  href="http://localhost:88/CNWeb123/CNWeb/">TRANG CHỦ</a>    
               </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">GIỚI THIỆU</div>
                <div class="dropdown-content">
                    <a href="#">Lời chào mừng</a>
                    <a href="#">Tổ chức</a>
                    <a href="#">Hợp tác liên kết</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">NGHIÊN CỨU KHOA HỌC</div>
                <div class="dropdown-content">
                    <a href="#">Các đề tài-dự án</a>
                    <a href="#">Hợp tác phát triển</a>

                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">ĐÀO TẠO</div>
                <div class="dropdown-content">
                    <a href="#">Đào tạo Đại học</a>
                    <a href="#">Đào tạo sau Đại học</a>
                    <a href="#">Chuẩn đầu ra</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">BỘ MÔN TRUNG TÂM</div>
                <div class="dropdown-content">
                    <a href="#">Công nghệ phần mềm</a>
                    <a href="#">Hệ thống thông tin</a>
                    <a href="#">Khoa học máy tính</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">TIN TỨC</div>
                <div class="dropdown-content">
                    <a href="#">Sự kiện</a>
                    <a href="#">CSE trên báo</a>

                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">THÔNG BÁO</div>
                <div class="dropdown-content">
                    <a href="#">Tuyển dụng</a>
                    <a href="#">TB đào tạo</a>
                    <a href="#">Học bổng</a>
                </div>
            </div>
            <div class="dropdown">
                <div class="dropbtn">LIÊN HỆ</div>

            </div>
        </ul>

    </nav>
    <div class="slidess">
        <div id="slides" class="carousel slides" data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#slides" data-slide-to="0" class="active"></li>
                <li data-target="#slides" data-slide-to="1"></li>
                <li data-target="#slides" data-slide-to="2"></li>
            </ul>
            <div class=" slideBanner carousel-inner">
                <div class="carousel-item active">
                    <img src="img/tsv.png" alt="">
                </div>
                <div class="carousel-item">
                    <img src="img/itt.jpg" alt="">
                    <div class="carousel-caption">
                        <h3>Công Nghê Thông Tin</h3>
                        <p>Xu hướng phát triển toàn cầu</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/bd.jpg" alt="">
                    <div class="carousel-caption">
                        <h3>Giải Bóng Đá Khoa</h3>
                        <p>Giải bóng đã đi đến những vòng đấu cuối cùng</p>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#slides" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#slides" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </div>
    <hr />
    <div class="main-1">
        <h2 style="  text-align: left; font-weight: inherit; color: #3333ff;" class="display">TIN TỨC</h2>
        <div class="jumbotron jumbotron-fluid">
            <div id="news" class="carousel slides" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#news" class="active"></li>
                    <li data-target="#news" data-slide-to="1"></li>
                    <li data-target="#news" data-slide-to="2"></li>
                </ul>
                <div class="lastNew carousel-inner">
                    <div class="carousel-item active">
                        <div class="col-12">
                            <div class="row text-center padding">
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic4.jpg" />
                                    <h5>Hội thảo "Sử dụng mạng xã hội an toàn - góc nhìn từ tiêu chuẩn cộng đồng
                                        facebook"
                                    </h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic5.jpg" />
                                    <h5>Kết quả nghiên cứu khoa học sinh viên lần thứ 32</h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic4.jpg" />
                                    <h5>Hội thảo "Sử dụng mạng xã hội an toàn - góc nhìn từ tiêu chuẩn cộng đồng
                                        facebook"
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-12">
                            <div class="row text-center padding">
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic4.jpg" />
                                    <h5>Hội thảo "Sử dụng mạng xã hội an toàn - góc nhìn từ tiêu chuẩn cộng đồng
                                        facebook"
                                    </h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic5.jpg" />
                                    <h5>Kết quả nghiên cứu khoa học sinh viên lần thứ 32</h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic5.jpg" />
                                    <h5>Kết quả nghiên cứu khoa học sinh viên lần thứ 32</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-12">
                            <div class="row text-center padding">
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic4.jpg" />
                                    <h5>Hội thảo "Sử dụng mạng xã hội an toàn - góc nhìn từ tiêu chuẩn cộng đồng
                                        facebook"
                                    </h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic5.jpg" />
                                    <h5>Kết quả nghiên cứu khoa học sinh viên lần thứ 32</h5>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <img style="width:100%;" src="img/pic6.jpg" />
                                    <h5>Công bố quyết định của Hiệu trưởng Bổ nhiệm viên chức quản lý cấp bộ môn khoa
                                        CNTT
                                    </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#news" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#news" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>

            </div>
        </div>
    </div>
    </div>

    <div class="main-2">
        <h2 style="text-align: left; font-weight: inherit; color: #3333FF" class="display">SỰ KIỆN</h2>
        <div class="jumbotron jumbotron-fluid">
            <div class="row text-center padding ">
                <div style="text-align: left; padding-left: 40px;" class="timeEvents col-xs-12 col-sm-3 col-md-3">
                    <div style="font-size: 100px; " class="date">22</div>
                    <div style="font-size: 25px;" class="month">December</div>
                </div>
                <div class="event-wrapper col-xs-12 col-sm-6 col-md-6">
                    <h3 style="text-align: left; padding-top: 30px;" class="title">
                        <a href="https://educationwp.thimpress.com/events/summer-school-2019/">Olympic Toán cấp
                            trường</a>
                    </h3>
                    <div style="text-align: left;" class="meta">
                        <div class="time">
                            <i class="fa fa-clock-o"> 8:00 AM - 17:00 AM</i>
                        </div>
                        <div class="location">
                            <i class="fa fa-map-marker"> T45 - Đại học Thủy Lợi</i>
                        </div>
                        <div class="description">
                            <p>Cuộc thi Olympic thưởng niên sẽ được diễn ra và ngày 20-9-2019. Mong rằng cuộc thi năm
                                nay chúng ta sẽ tìm ra được những nhân
                                tài toán học để tiếp đó tham dự cuộc thi Olympic Toán cả Nước....
                            </p>
                        </div>
                    </div>
                </div>
                <div class="img col-xs-12 col-sm-3 col-md-3">
                    <img style="height: 200px; width:230px; padding-top: 30px; padding-right: 30px;" src="img/pic8.jpg"
                        alt="">
                </div>
            </div>
            <hr />
            <div class="row text-center padding ">
                <div style="text-align: left; padding-left: 40px;" class="timeEvents col-xs-12 col-sm-3 col-md-3">
                    <div style="font-size: 100px; " class="date">25</div>
                    <div style="font-size: 25px;" class="month">December</div>
                </div>
                <div class="event-wrapper col-xs-12 col-sm-6 col-md-6">
                    <h3 style="text-align: left; padding-top: 30px;" class="title">
                        <a href="https://educationwp.thimpress.com/events/summer-school-2019/">Đêm ca nhạc chào tân sinh
                            viến</a>
                    </h3>
                    <div style="text-align: left;" class="meta">
                        <div class="time">
                            <i class="fa fa-clock-o"> 19:00 PM - 22:00 PM</i>
                        </div>
                        <div class="location">
                            <i class="fa fa-map-marker"> T45 - Đại học Thủy Lợi</i>
                        </div>
                        <div class="description">
                            <p>Tại hội trường T45 thân yêu cuối tuần này sẽ diễn ra đêm ca nhạc hoành tráng để chào mừng
                                các tân sinh viên K61 đại học Thủy Lợi....</p>
                        </div>
                    </div>
                </div>
                <div class="img col-xs-12 col-sm-3 col-md-3">
                    <img style="height: 200px; width:230px; padding-top: 30px; padding-right: 30px;" src="img/nhac.jpg"
                        alt="">
                </div>
            </div>
        </div>
    </div>

    <div class="main-3">
        <h2 style="text-align: left; font-weight: inherit; color: #3333FF" class="display">THÔNG TIN CÔNG NGHỆ</h2>
        <div class="jumbotron jumbotron-fluid">
            <div class="row text-center padding ">

                <div class="event-wrapper col-xs-12 col-sm-6 col-md-8">
                    <h3 style="text-align: center ; padding-top: 30px 0px 0px 80px;" class="title">
                        <a href="https://educationwp.thimpress.com/events/summer-school-2019/">Vì sao tôi trở thành
                            chuyên gia AI?</a>
                    </h3>
                    <div style="text-align: left;" class="meta">

                        <div style="text-align: left; padding-left: 110px" class="description">
                            <p>Anh chàng lập trình viên tự viết phần mềm nhận diện khuôn mặt sếp để tránh bị phát hiện
                                khi đang lén chơi
                                game....
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <hr />

            <div class="row text-center padding ">
                <div class="event-wrapper col-xs-12 col-sm-6 col-md-8">
                    <h3 style="text-align: center ; padding-top: 30px 0px 0px 80px; width: 800px;" class="title">
                        <a href="https://techtalk.vn/bao-cao-so-lieu-nganh-cntt-soan-ngoi-dau-mua-tuyen-sinh-2019.html">Báo cáo số liệu: Ngành
                            CNTT dẫn đầu tuyển sinh
                        </a>
                    </h3>
                    <div style="text-align: left;" class="meta">
                        <div style="text-align: left; padding-left: 110px" class="description">
                            Trong mùa tuyển sinh năm 2019 có khá nhiều bất ngờ khi ngành công nghệ thông tin (CNTT) đã
                            “soán
                            ngôi” đầu khi vượt xa điểm chuẩn các ngành y, dược, mặc dù điểm chuẩn của các ngành đã tăng
                            mạnh
                            trong năm nay. ....
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <div class="footer-end">
        <footer class="page-footer font-small blue pt-4">
            <div class="container-fluid text-center text-md-left">
                <div class="row">
                    <div class="col-md-6 mt-md-0 mt-3">
                        <h5 class="text-uppercase">© 2019 Khoa Công nghệ thông tin - Đại học Thủy lợi</h5>
                        <p>Địa chỉ: nhà C1, Đại học Thủy lợi, 175 Tây Sơn, Đống Đa, Hà Nội.</p>
                        <p>Điện thoại: (+84)-024 3 5632211. Email: vpkcntt@tlu.edu.vn.</p>
                    </div>
                    <hr class="clearfix w-100 d-md-none pb-3">
                    <div class="col-md-3 mb-md-0 mb-3">
                        <h5 class="text-uppercase">GIỚI THIỆU</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">Lời chào mừng</a>
                            </li>
                            <li>
                                <a href="#">Tổ chức</a>
                            </li>
                            <li>
                                <a href="#!">Hợp tác liên kết</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-3 mb-md-0 mb-3">
                        <h5 class="text-uppercase">ĐÀO TẠO</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#!">Đào tạo Đại học</a>
                            </li>
                            <li>
                                <a href="#!"> Đào tại sau Đại học</a>
                            </li>
                            <li>
                                <a href="#!">Chuẩn đầu ra</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-copyright text-center py-3">© 2019 - 2020:
                <a href="http://www.tlu.edu.vn/"> Đại Học Thủy Lợi</a>
            </div>
        </footer>
    </div>

</body>

</html>