<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    require ('mysqli_connect.php');
    
	    $email = filter_var( $_POST['email'], FILTER_SANITIZE_EMAIL);	
	if  ((empty($email)) || (!filter_var($email, FILTER_VALIDATE_EMAIL))) {
		$errors[] = 'You forgot to enter your email address';
		$errors[] = ' or the e-mail format is incorrect.';
	}
    
	    $password = filter_var( $_POST['password'], FILTER_SANITIZE_STRING);	
	if (empty($password)) {
		$errors[] = 'You forgot to enter your password.';
	}
   if (empty($errors)) { 
 $query = "SELECT password, user_level FROM users WHERE email='$email'";
 $result = mysqli_query($dbcon, $query);

$row = mysqli_fetch_array($result);
if ($result == 1) {

if (password_verify($password, $row["password"])) {          
session_start();								
$_SESSION['user_level'] = (int) $row["user_level"];

$url = ($_SESSION['user_level'] === 1) ? 'admin.php' :
 'member.php'; 
header('Location: ' . $url); 

} 
else{
    echo('Fail');
}
}
   }
}
?>